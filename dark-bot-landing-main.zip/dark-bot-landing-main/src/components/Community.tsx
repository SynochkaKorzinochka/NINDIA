import { cn } from "@/lib/utils"
import { TestimonialCard, TestimonialAuthor } from "@/components/ui/testimonial-card"
import { motion } from "framer-motion"

interface CommunityTestimonial {
  author: TestimonialAuthor
  text: string
  href?: string
}

const testimonials: CommunityTestimonial[] = [
  {
    author: {
      name: "Emma Thompson",
      handle: "@emmaai",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face"
    },
    text: "Using NINDIA AI platform has transformed how we handle data analysis. The speed and accuracy are unprecedented",
    href: "#"
  },
  {
    author: {
      name: "David Park",
      handle: "@davidtech",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    text: "The API integration is flawless. We've reduced our development time by 60% since implementing $NINDIA solution",
    href: "#"
  },
  {
    author: {
      name: "Sofia Rodriguez",
      handle: "@sofiaml",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face"
    },
    text: "Finally, an AI tool that actually understands context! NINDIA accuracy in natural language processing is impressive"
  }
];

export const Community = () => {
  return (
    <section 
      id="community"
      className={cn(
        "bg-transparent text-foreground relative",
        "py-12 sm:py-24 md:py-32 px-0",
      )}
    >
      {/* Background glow - behind everything */}
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none -z-10">
        <div 
          className="absolute w-[700px] h-[500px] rounded-[50%] blur-[150px] opacity-40"
          style={{
            background: 'radial-gradient(ellipse at center, hsla(28, 100%, 50%, 0.4) 0%, hsla(36, 100%, 62%, 0.2) 50%, transparent 80%)'
          }}
        />
      </div>
      
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 text-center sm:gap-16 relative z-10">
        <motion.div 
          className="flex flex-col items-center gap-4 px-4 sm:gap-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
        >
          <h2 className="max-w-[720px] text-4xl md:text-5xl font-bold text-gradient">
            Community
          </h2>
          <p className="text-xl max-w-[600px] text-muted-foreground">
            Join thousands of developers who are already building the future by growing the $NINDIA economy with our artificial intelligence platform
          </p>
        </motion.div>

        <motion.div 
          className="relative flex w-full flex-col items-center justify-center overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6, delay: 0.2, ease: [0.25, 0.4, 0.25, 1] }}
        >
          <div className="group flex overflow-hidden p-2 [--gap:1rem] [gap:var(--gap)] flex-row [--duration:40s]">
            <div className="flex shrink-0 justify-around [gap:var(--gap)] animate-marquee flex-row group-hover:[animation-play-state:paused]">
              {[...Array(4)].map((_, setIndex) => (
                testimonials.map((testimonial, i) => (
                  <TestimonialCard 
                    key={`${setIndex}-${i}`}
                    {...testimonial}
                  />
                ))
              ))}
            </div>
          </div>

          {/* Fade edges - matching background */}
          <div className="pointer-events-none absolute inset-y-0 left-0 hidden w-1/4 sm:block" style={{ background: 'linear-gradient(to right, hsl(0 0% 4%), transparent)' }} />
          <div className="pointer-events-none absolute inset-y-0 right-0 hidden w-1/4 sm:block" style={{ background: 'linear-gradient(to left, hsl(0 0% 4%), transparent)' }} />
        </motion.div>
        
        <motion.div 
          className="mt-8 flex justify-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3, ease: [0.25, 0.4, 0.25, 1] }}
        >
          <a 
            href="#" 
            className="inline-flex items-center gap-2 px-8 py-3 rounded-full bg-transparent hover:bg-primary/10 border border-border hover:border-primary/50 transition-all hover-glow text-foreground"
          >
            <span className="text-sm font-medium">Join the community</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
};
