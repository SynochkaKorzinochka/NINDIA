import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";

const faqs = [
  {
    question: "What is NINDIA and how does it work?",
    answer: "NINDIA — is an intelligent neural network designed to automate routine tasks. It analyzes requests, processes information and performs tasks in the same way as a virtual assistant. All you have to do is enter the task — NINDIA will do everything itself.",
    category: "BASICS"
  },
  {
    question: "What makes NINDIA different from standard chatbots?",
    answer: "Unlike standard chatbots with limited scripts, NINDIA understands crypto terms, adapts to your strategies and is capable of performing complex tasks. It doesn't just respond — it works in your place: it analyzes graphs, data, processes information and automates processes.",
    category: "DIFFERENCE"
  },
  {
    question: "Can sensitive data be safely stored and processed through NINDIA?",
    answer: "Yes. All data undergoes secure processing and is not transferred to third parties. NINDIA uses modern security techniques to ensure privacy and does not use your data for training without permission.",
    category: "SECURITY"
  },
  {
    question: "How do I start using NINDIA — where to start if I want to connect it to my project?",
    answer: "Simply register on the platform, select the appropriate tariff and open the control panel. There you can configure the neural network, connect integrations, download your data and immediately start using NINDIA for any task.",
    category: "USE"
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut" as const
    }
  }
};

export const FAQ = () => {
  return (
    <section id="faq" className="py-24 relative bg-transparent">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <motion.div 
            className="space-y-6 lg:sticky lg:top-24"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <span className="text-sm tracking-widest text-muted-foreground uppercase">
              QUESTIONS
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-gradient">
              Focus on the signal, not the noise.
            </h2>
            <p className="text-xl text-muted-foreground">
              Everything you need to know about working with NINDIA is written here in a short and understandable format.
            </p>
          </motion.div>

          <motion.div 
            className="space-y-4"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
          >
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <AccordionItem 
                    value={`item-${index}`}
                    className="border border-border rounded-lg bg-card/50 backdrop-blur-sm px-6 data-[state=open]:border-primary/50"
                  >
                    <AccordionTrigger className="text-left hover:no-underline py-6">
                      <div className="flex flex-col items-start gap-2 pr-4">
                        <span className="text-sm text-muted-foreground tracking-wider">
                          {faq.category}
                        </span>
                        <span className="text-lg font-semibold text-foreground">
                          {faq.question}
                        </span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground pb-6">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
