import { Github, Twitter } from "lucide-react";
import { Footer as FooterUI } from "@/components/ui/footer";
import nindiaLogo from "@/assets/nindia-logo.png";

export const Footer = () => {
  const socialLinks = [
    { icon: <Twitter className="w-5 h-5" />, href: "#", label: "Twitter" },
    { icon: <Github className="w-5 h-5" />, href: "#", label: "GitHub" },
  ];

  const mainLinks = [
    { href: "#features", label: "Features" },
    { href: "#pricing", label: "Pricing" },
    { href: "#community", label: "Community" },
    { href: "#faq", label: "FAQ" },
  ];

  const legalLinks: Array<{ href: string; label: string }> = [];

  return (
    <FooterUI
      logo={<img src={nindiaLogo} alt="NINDIA logo" className="h-10 w-auto" />}
      brandName="NINDIA"
      socialLinks={socialLinks}
      mainLinks={mainLinks}
      legalLinks={legalLinks}
      copyright={{
        text: "© 2025 NINDIA",
        license: "All rights reserved",
      }}
    />
  );
};
