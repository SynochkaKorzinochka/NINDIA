"use client";
import React from "react";
import { cn } from "@/lib/utils";

export const LampContainer = ({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) => {
  return (
    <div
      className={cn(
        "relative flex min-h-[600px] flex-col items-center justify-center overflow-hidden w-full",
        className
      )}
    >
      {children && (
        <div className="relative z-10 flex flex-col items-center px-5">
          {children}
        </div>
      )}
    </div>
  );
};