import { PricingSection } from "@/components/ui/pricing";

const pricingPlans = [
  {
    name: "Starter",
    price: "50",
    yearlyPrice: "40",
    period: "month",
    features: [
      "Up to 10 projects",
      "$NINDIA analytics",
      "48-hour support response time",
      "Limited API access",
      "Community support",
    ],
    description: "Perfect for individuals and small projects",
    buttonText: "Start Free Trial",
    href: "#",
  },
  {
    name: "Professional",
    price: "99",
    yearlyPrice: "79",
    period: "month",
    features: [
      "Unlimited projects",
      "Personal $NINDIA AI-assistant.",
      "24-hour support response time",
      "Full API access",
      "Priority support & Team collaboration",
    ],
    description: "Ideal for growing teams and businesses",
    buttonText: "Get Started",
    href: "#",
    isPopular: true,
  },
  {
    name: "Enterprise",
    price: "299",
    yearlyPrice: "239",
    period: "month",
    features: [
      "Everything in Professional",
      "Custom solutions & integrations",
      "Dedicated account manager",
      "SSO Authentication & Advanced security",
      "Insider info about $NINDIA",
    ],
    description: "For large organizations with specific needs",
    buttonText: "Contact Sales",
    href: "#",
  },
];

export const Pricing = () => {
  return (
    <PricingSection
      plans={pricingPlans}
      title="Pricing"
      description="Join $NINDIA! Use the power of AI to the maximum. Choose how you want to participate in the private artificial intelligence revolution."
    />
  );
};
