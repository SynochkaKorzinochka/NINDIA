import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen } from "lucide-react";
import { SplineScene } from "@/components/ui/splite";
import { motion } from "framer-motion";
import { AiChatDialog } from "@/components/ui/ai-chat-dialog";

export const Hero = () => {
  const [isAiDialogOpen, setIsAiDialogOpen] = useState(false);

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-20">
      
      <div className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text Content */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <div className="space-y-6">
              <h1 className="text-5xl md:text-7xl font-bold leading-tight">
                <span className="text-gradient">
                  Indian
                </span>
                <br />
                <span className="text-gradient">
                  Processing Unit
                </span>
                <br />
                <span className="text-foreground">for Modern Indian Team</span>
              </h1>
              
              <motion.p 
                className="text-xl md:text-2xl text-muted-foreground max-w-2xl leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2, ease: [0.25, 0.4, 0.25, 1] }}
              >
                Transform your workflow with AI. Automate complex tasks, run nodes, handle private workloads, and support $NINDIA
              </motion.p>
            </div>

            <motion.div 
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3, ease: [0.25, 0.4, 0.25, 1] }}
            >
              <Button 
                size="lg" 
                className="text-lg px-8 py-6 bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground hover-glow group"
                onClick={() => setIsAiDialogOpen(true)}
              >
                Get Started
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 py-6 border-border hover:border-primary/50 hover:bg-secondary group"
              >
                <BookOpen className="mr-2 h-5 w-5" />
                Documentation
              </Button>
            </motion.div>

            <motion.div 
              className="flex items-center gap-8 text-sm text-muted-foreground pt-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-glow"></div>
                <span>No credit card required</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-glow"></div>
                <span>Free 14-day trial</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Right: 3D Robot */}
          <motion.div 
            className="relative h-[500px] lg:h-[700px]"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <SplineScene 
              scene="https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode"
              className="w-full h-full"
            />
          </motion.div>
        </div>
      </div>

      <AiChatDialog open={isAiDialogOpen} onOpenChange={setIsAiDialogOpen} />
    </section>
  );
};
