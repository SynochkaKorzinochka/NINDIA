import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { Features } from "@/components/Features";
import { Pricing } from "@/components/Pricing";
import { Community } from "@/components/Community";
import { FAQ } from "@/components/FAQ";
import { Footer } from "@/components/Footer";
import { LampContainer } from "@/components/ui/lamp";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="relative">
        <div className="absolute top-0 left-0 right-0 w-full pointer-events-none">
          <LampContainer className="min-h-[600px]" />
        </div>
        <div className="relative z-10">
          <Hero />
        </div>
      </div>
      <Features />
      <Pricing />
      <Community />
      <FAQ />
      <Footer />
    </div>
  );
};

export default Index;
